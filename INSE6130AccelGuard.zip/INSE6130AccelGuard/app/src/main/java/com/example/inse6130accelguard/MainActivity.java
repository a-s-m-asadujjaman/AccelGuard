package com.example.inse6130accelguard;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.graphics.Color;
import android.widget.TextView;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {

    private  Accelerometer accelerometer;

    TextView hello;
    TextView detection;
    ProgressBar progress;
    double notifyTime=0;
    double newTime;
    double delay;
    double frequency;
    double maxFrequency=0;
    double firstDelay=0;
    double secondDelay=0;
    boolean detectionUpdated=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        hello =(TextView) findViewById(R.id.hello);
        detection =(TextView) findViewById(R.id.textViewDetection);
        //progress = (ProgressBar) findViewById(R.id.progressBar2);
        //hello.setText("Freq " + System.currentTimeMillis());

        accelerometer = new Accelerometer(this);

        accelerometer.setListener(new Accelerometer.Listener() {
            @Override
            public void onTranslation(float tx, float ty, float tz) {
                newTime=(double)System.currentTimeMillis()/1000;
                if(notifyTime==0)
                {
                    notifyTime=newTime;
                }
                else
                {
                    delay=newTime-notifyTime;
                    if (firstDelay==0)
                        firstDelay=delay;
                    else if(secondDelay==0)
                        secondDelay=delay;
                    else if (!detectionUpdated) {
                        if(firstDelay/secondDelay>1.1)
                            detection.setText("Malicious application detected!");
                        detectionUpdated=true;
                    }
                    if(delay>0) {
                        frequency = 1.0 / delay;
                        if (frequency > maxFrequency) {
                            maxFrequency = frequency;
                        }
                        hello.setText("" + (int)maxFrequency/2+" Hz");
                        //progress.setMax((int)maxFrequency/4);
                        //progress.setProgress((int)(frequency<(maxFrequency/4)?frequency:(maxFrequency/4)));

                        notifyTime = newTime;
                    }
                }
                //hello.setText("Freq " + tx);
            }
        });

    }
    protected void onResume()
    {
        super.onResume();

        accelerometer.register();

    }
    protected void onPause()
    {
        super.onPause();

        accelerometer.unregister();

    }
}
